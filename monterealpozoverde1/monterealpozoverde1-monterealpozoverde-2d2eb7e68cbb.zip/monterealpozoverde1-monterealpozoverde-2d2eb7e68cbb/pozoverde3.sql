CREATE Database MonteRealPozoVerde;

CREATE TABLE public.tbl_tipo_empleado
(
  id_tipo_empleado integer NOT NULL DEFAULT nextval('tbl_tipo_empleado_id_tipo_empleado_seq'::regclass),
  descripcion text NOT NULL,
  CONSTRAINT tbl_tipo_empleado_pkey PRIMARY KEY (id_tipo_empleado),
  CONSTRAINT tbl_tipo_empleado_descripcion_key UNIQUE (descripcion)
 );


CREATE TABLE public.usuario
(
  id_usuario bigint NOT NULL DEFAULT nextval('usuario_id_usuario_seq'::regclass),
  usuario character varying(25) NOT NULL,
  kword character varying(25) NOT NULL,
  id_empleado bigint NOT NULL,
  id_tipo_empleado bigint NOT NULL,
  CONSTRAINT pk_usuario PRIMARY KEY (id_usuario),
  CONSTRAINT fk_tbl_empleados FOREIGN KEY (id_empleado)
      REFERENCES public.tbl_empleados (id_empleado) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT fk_tbl_tipo_empleado FOREIGN KEY (id_tipo_empleado)
      REFERENCES public.tbl_tipo_empleado (id_tipo_empleado) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE public.tbl_tipo_empleado
(
  id_tipo_empleado integer NOT NULL DEFAULT nextval('tbl_tipo_empleado_id_tipo_empleado_seq'::regclass),
  descripcion text NOT NULL,
  CONSTRAINT tbl_tipo_empleado_pkey PRIMARY KEY (id_tipo_empleado),
  CONSTRAINT tbl_tipo_empleado_descripcion_key UNIQUE (descripcion)
)Eisner Lopez Acevedo
