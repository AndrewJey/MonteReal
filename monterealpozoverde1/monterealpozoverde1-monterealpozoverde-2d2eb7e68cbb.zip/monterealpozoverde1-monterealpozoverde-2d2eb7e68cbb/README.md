# README #


- PROYECTO: 
MONTEREAL-POZO VERDE

- EQUIPOS DE DESARROLLO: 
Guerreros de Luz y Universidad Católica – Generación 2015

- SISTEMA: 
Facturación Instalable, Conexión a Red para Atención Cliente, Sistema Android Informativo 

- LENGUAJES: 
C#, Android, PHP

- SUB-VERSIONAMIENTO: 
BitBucket (repositorio privado)

 CLIENTE: 
Douglas Vargas V.

- RESPONSABLE A CARGO: 
Andrés J. Jiménez Leandro

- DESARROLLADORES DEL PROYECTO: 
Andrés J. Jiménez Leandro
Oscar F. Fonseca Salicetti
Ronald D. Acuña Arias
Arbay J. Fernández Solano
Andrés G. Matta Morales
Hellen Ma López Arrieta
José Miguel Rojas Guerrero
Eisner López Acevedo






Requisitos del Cliente
Sistema Informático Instalable:
Sistema en modo gráfico (debe verse cómo una factura) de Facturación oficializado
Facturación de Cabinas y Restaurante en una sola Colilla
Desgloses de Facturación predeterminada y para agregar adicional
Sistema en modo Gráfico (con dibujos) y Escrito de Selección en la Facturación
Consideraciones de Descuentos 
Consideraciones de Impuestos:
Ventas al 13%
Servicio Restaurante al 10%
Cálculo de Costos:
Cierre de Caja
Caja Chica
Costos
Ganancias con Porcentajes Fijos (El descuento no debe afectar las ganancias)
Sistema de Contabilidad
Cálculo de Créditos y Débitos :: Debe y Haber Contable
Porcentaje de Ventas de Productos
Rentabilidad y Pérdidas de Productos
Sistema de Graficación y Estadística para los sistemas de:
Cálculos de Costos
Facturas Pagadas y sus totales
Visitas mensuales al restaurante
Visitas mensuales a las habitaciones
Visitas de Clientes registrados
Logueos y tiempos trabajados de los otros usuarios por semana
Cotizaciones y Proformas realizadas en el mes
Sistema de Enmiendas
Log de Errores semanales
Reportes de Inventario Dañado por mes
 Códigos de Ventas:
100-149 Desayunos
150-199 Bebidas
200-249 Entradas
250-399 Platos Fuertes
400-449 Cabinas
450-499 Adicionales: Salón de Eventos, Sendero, Visitas Guiadas, etc…
500-600 Extras (Persona extra, toallas extras, vino en habitación, etc…)
Acceso y Registro por Mesas: Pero debe permitir manejo de datos y facturación individual
Sistema de Cotización y Proformas
Creación de Reportes: 
Reportar Cambios en Base de Datos
Log de Errores de Sistema
Reporte de Ingresos
Reporte en pantalla de todos las áreas del Sistema
Reporte de Devoluciones y Cancelaciones
Reporte de Facturación y Cambios
Reporte de Costos
Reporte de Cobros por Inventario Dañado
Sistema de Enmiendas:
Cambios a Facturas
Cambios a Costos
Cambios a Solicitudes Procesadas en las áreas de:
Restaurante
Habitaciones
Servicios Adicionales
Impresión de Datos
Sistema de Calificación y Recomendaciones
Versión Cliente y Versión Administrativa
Tres Niveles de Permisos de Acceso:
Usuario Administrativo General
4 Usuarios de Facturación
1 Usuario de Cliente (para selección de datos y conexión a sistema Android y Red Interna)
Sistemas de Creación, Revisión, Actualización y Borrado para:
Usuarios
Perfiles de Usuarios
Menú:
Comidas
Bebidas / Botellas
Combos de Comidas
Clientes:
Clientes Físicos
Clientes Jurídicos
Preferencias de los Clientes
Ofertas y Temporadas
Recargos:
Servicios Adicionales
Precios
Cabinas
Cobros por Inventario Dañado
Facturas
Conceptos Adicionales (Ingreso Manual)
Conceptos Gratuitos (Ingreso Manuales)
Tipos de Pago
Efectivo (Ingreso Manual)
Cheque
Tarjetas Bancarias
Mixto
Alarmas y Correos Masivos
Fechas de Lanzamiento
Establecer Servidor de Correo SMPT interno
Instalador del software, con contrato de uso, y pantallas de ayuda para instalación con opción de “Siguiente” y “Aceptar”
Sistema de Respaldos por “YYYY-MM-dd_HH:MM:ss.extensión” de Sistema para:
Estado del Sistema
Bases de Datos
Reportes
Gráficas y Estadísticas
Sistema de Costos
Sincronizar los respaldos en línea (dependiente de internet) por si se daña disco duro con respaldos:
Programar synch para escogencia en tiempos.

Sistema Web/Red Interna:
Sistema de Acceso a un Menú de Usuario, dónde el cliente pueda seleccionar sus comidas y bebidas, de acuerdo a lo presente en la Base de Datos, por medio de sistema táctil:
Los códigos de producto no deben ser vistos por el cliente, solo el nombre y foto del platillo
La factura debe irse creando según se selecciona
La selección es establecida por mesa (pero se puede cobrar cada plato individual)
La actualización al menú en la bases de datos, debe ser de sincronización inmediata
Se debe ir creando orden en sistema visual de la cocina, conforme se selecciona
Los cambios hechos por el cliente deben ser sincronizados inmediatamente y registrados los precios
Debe haber un temporizador, dónde se estime el tiempo de preparación del plato en la cocina; si dicho tiempo expira, la solicitud ya no podrá ser cambiada.
Lo mismo del punto anterior, pero en bebidas naturales y/ó batidos.
Debe haber un sistema visual para la cocina, que se sincroniza con el sistema de menú de los clientes.
Al sistema de menú de usuario, debe haber la posibilidad de seleccionar un cliente registrado en sistema.
Solo el administrativo puede hacer uso del CRUD de los clientes
El usuario administrativo puede enviar correos masivos registrados y alarmas a los sistemas Android
Crear servicios web (web services) para todas las conexiones anteriores, y establecer API’s necesarios
Hacer LAN interna con router dedicado (ver posibilidad de WPS), para que la presencia de Internet no afecte el trabajo
Sistema de Calificación:
Restaurante
Cabinas
Menú
Atención General
Servicios Adicionales
Sistema de Sugerencias y Recomendaciones
Visible desde el menú de acceso de los clientes
Sistema de Quejas
Atendido por códigos de los 700’s a los 900’s
Solo el administrativo puede visualizarlos

Sistema Android:
Sección Informativa del sitio
Menú de Alimentación
Cabinas
Servicios Adicionales
Costos actuales
Sección de Contacto (Información de Contacto)
Con posibilidad de CRUD en reservación por parte del cliente
Dicha fecha de reservación, debe ser validada para que no choque con fecha y hora ya reservada
Dicha fecha de reservación debe ser aprobada por el administrador (notificación inmediata de aprobación a celular solicitante)
Sección de registro de usuario (el mismo afecta el CRUD de clientes, agregando a cada cliente registrado)
Recepción de Alarmas y Notificaciones de parte del Administrador (que las envía por medio de sistema web)